/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog5121part2;

/**
 *
 * @author NTOKOZO
 */

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Message class for QuickChat application.
 * Handles validation, hash generation, sending/storing logic, and persistence.
 */
public class Message {

    // Instance variables
    private final String messageID;
    private String messageHash;
    private final String recipient;
    private final String message;
    private final int messageSent;
    private static int totalMessagesSent = 0;

    // Constructor: initializes a new Message object
    public Message(String messageID, String recipient, String message) {
        this.messageID = messageID;
        this.recipient = recipient;
        this.message = message;
        this.messageSent = totalMessagesSent;
    }

    // Validate message ID length
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    // Validate recipient: must be exactly 10 digits
    public String checkRecipientCell() {
        if (recipient == null || !recipient.matches("^\\d{10}$")) {
            return "Cell phone number is incorrectly formatted. Please enter a 10-digit SA number (e.g., 0699411905).";
        }
        return "Cell phone number successfully captured.";
    }

    // Create hash: XX:Y:FIRSTWORDLASTWORD
    public String createMessageHash() {
        String idPrefix = (messageID != null && messageID.length() >= 2)
                ? messageID.substring(0, 2).toUpperCase()
                : "00";

        String[] words = message.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0].replaceAll("[^a-zA-Z0-9]", "").toUpperCase() : "";
        String lastWord = words.length > 0 ? words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "").toUpperCase() : "";

        this.messageHash = idPrefix + ":" + messageSent + ":" + firstWord + lastWord;
        return this.messageHash;
    }

    /**
     * Handles user choice for message action using switch.
     * Options: send, disregard, store.
     * @param choice user input (string)
     * @return result message string
     */
    public String sentMessage(String choice) {
        if (choice == null) {
            return "No action selected.";
        }
        choice = choice.trim().toLowerCase();

        switch (choice) {
            case "1":
            case "send":
                totalMessagesSent++;
                return "Message successfully sent.";
            case "2":
            case "disregard":
                return "Message disregarded.";
            case "3":
            case "store":
                return "Message successfully stored.";
            default:
                return "Invalid choice. Please select send, disregard, or store.";
        }
    }

     /**
     * Returns formatted string of message details.
     * @return formatted message info
     */
    public String printMessages() {
        return "MessageID: " + messageID + "\n" +
               "Message Hash: " + messageHash + "\n" +
               "Recipient: " + recipient + "\n" +
               "Message: " + message;
    }

     /**
     * Returns total number of messages sent.
     * @return integer count of sent messages
     */
    public int returnTotalMessages() {
        return totalMessagesSent;
    }
    
    public void storeMessage() {
        try (FileWriter fileWriter = new FileWriter("message.json", true)){
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            String json = gson.toJson(this);
            fileWriter.write(json + "\n");
            fileWriter.close();
        } catch (IOException e) {
            System.err.println("Error storing message: " + e.getMessage());
        }
    }

    // Getters
    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }

    // Static methods for global counter
    public static int getTotalMessagesSent() { return totalMessagesSent; }
    public static void resetTotalMessages() { totalMessagesSent = 0; }
}
