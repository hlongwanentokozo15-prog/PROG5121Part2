/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog5121part2;

/**
 *
 * @author NTOKOZO
 */

import java.util.Random;
import javax.swing.JOptionPane;
import java.util.ArrayList;

/**
 * QuickChat main class.
 * Provides login, menu navigation, sending messages, and viewing recent messages.
 */
public class QuickChat {
    // Stores all sent messages for later viewing
    private final static ArrayList<Message> sentMessages = new ArrayList<>();
    
    public static void main(String[] args) {
        // Prompt user for login credentials
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        
        // Simple login check
        if ("student".equals(username) && "1234".equals(password)) {
            JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");
            menu(); // Show main menu after successful login
        } else {
            JOptionPane.showMessageDialog(null, "Invalid login.");
        }
    }
     /**
     * Displays the main menu with options.
     * Uses a switch statement to handle user choice.
     */
    private static void menu() {
        while (true) {
            String choice = JOptionPane.showInputDialog(
                    "Choose an option:\n1) Send Messages\n2) Show recently sent messages\n3) Quit");
            
            // If user cancels input, exit program
            if (choice == null) {
                JOptionPane.showMessageDialog(null, "Goodbye!");
                break;
            }

            // Handle menu options using switch
            switch (choice) {
                case "1":
                    sendMessages(); // Send new messages
                    break;
                case "2":
                    showRecentMessages(); // Display last 5 sent messages
                    break;
                case "3":
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                    return; // Exit program
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }

    /**
     * Handles sending messages.
     * Prompts user for recipient and message text, generates a random ID,
     * and allows user to choose whether to send, disregard, or store the message.
     */
    private static void sendMessages() {
        String numStr = JOptionPane.showInputDialog("How many messages do you want to send?");
        if (numStr == null) return; // Cancel if user closes dialog
        int num = Integer.parseInt(numStr);

        for (int i = 0; i < num; i++) {
            // Generate random numeric ID for each message
            String id = String.valueOf(new Random().nextInt(999999999));
            // Prompt for recipient number (must be 10 digits)
            String recipient = JOptionPane.showInputDialog("Enter recipient number (10 digits,e.g., 0699411905):");
            // Prompt for message text
            String text = JOptionPane.showInputDialog("Enter your message (max 250 chars):");

            // Create new Message object
            Message msg = new Message(id, recipient, text);

            // Validate recipient number
            JOptionPane.showMessageDialog(null, msg.checkRecipientCell());
            // Generate message hash
            msg.createMessageHash();

            // Show message details and ask user what to do with it
            String action = JOptionPane.showInputDialog(
                    msg.printMessages() + "\n\nChoose:\n1) Send Message\n2) Disregard Message\n3) Store Message");

            // Process action using Message class logic
            String result = msg.sentMessage(action);
            JOptionPane.showMessageDialog(null, result);

            // If user chose to send, add to sentMessages list
            if ("1".equals(action)) {
                sentMessages.add(msg);
            }
        }

        // Show total messages sent so far
        JOptionPane.showMessageDialog(null, "Total messages sent: " + Message.getTotalMessagesSent());
    }

     /**
     * Displays up to 5 most recent sent messages.
     * If no messages have been sent, shows a warning.
     */
    private static void showRecentMessages() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages sent yet.");
            return;
        }
        StringBuilder display = new StringBuilder("Recently sent messages:\n\n");
        // Show last 5 messages (or fewer if less than 5 exist)
        int start = Math.max(0, sentMessages.size() - 5);
        for (int i = start; i < sentMessages.size(); i++) {
            display.append(sentMessages.get(i).printMessages()).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, display.toString());
    }
}
