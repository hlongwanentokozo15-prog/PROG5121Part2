/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package prog5121part2;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Unit tests for the Message class.
 * Each test checks a specific method to ensure correct behavior.
 */
public class MessageIT {

    @Before
    public void resetCounter() {
        // Reset static counter before each test to avoid side effects
        Message.resetTotalMessages();
    }

    /**
     * Test checkMessageID with valid ID length.
     */
    @Test
    public void testCheckMessageIDValid() {
        Message instance = new Message("MSG001", "0821234567", "Hello");
        assertTrue(instance.checkMessageID());
    }

    /**
     * Test checkMessageID with invalid ID length (>10 chars).
     */
    @Test
    public void testCheckMessageIDInvalid() {
        Message instance = new Message("LONGMESSAGEID", "0821234567", "Hello");
        assertFalse(instance.checkMessageID());
    }

    /**
     * Test checkRecipientCell with valid number.
     */
    @Test
    public void testCheckRecipientCellValid() {
        Message instance = new Message("MSG001", "0821234567", "Hello");
        assertEquals("Cell phone number successfully captured.", instance.checkRecipientCell());
    }

    /**
     * Test checkRecipientCell with invalid number (too short).
     */
    @Test
    public void testCheckRecipientCellInvalid() {
        Message instance = new Message("MSG001", "08212345", "Hello");
        assertEquals(
            "Cell phone number is incorrectly formatted. Please enter a 10-digit SA number (e.g., 0699411905).",
            instance.checkRecipientCell()
        );
    }

    /**
     * Test createMessageHash method.
     */
    @Test
    public void testCreateMessageHash() {
        Message instance = new Message("MSG001", "0821234567", "Hello Ntokozo");
        String hash = instance.createMessageHash();
        assertTrue(hash.startsWith("MS:"));   // ID prefix
        assertTrue(hash.contains("HELLO"));   // first word
        assertTrue(hash.contains("NTOKOZO")); // last word
    }

    /**
     * Test sentMessage with "send" choice.
     */
    @Test
    public void testSentMessageSend() {
        Message instance = new Message("MSG001", "0821234567", "Hello");
        String result = instance.sentMessage("1");
        assertEquals("Message successfully sent.", result);
        assertEquals(1, Message.getTotalMessagesSent());
    }

    /**
     * Test sentMessage with "disregard" choice.
     */
    @Test
    public void testSentMessageDisregard() {
        Message instance = new Message("MSG001", "0821234567", "Hello");
        String result = instance.sentMessage("2");
        assertEquals("Message disregarded.", result);
        assertEquals(0, Message.getTotalMessagesSent());
    }

    /**
     * Test sentMessage with "store" choice.
     */
    @Test
    public void testSentMessageStore() {
        Message instance = new Message("MSG001", "0821234567", "Hello");
        String result = instance.sentMessage("3");
        assertEquals("Message successfully stored.", result);
        assertEquals(0, Message.getTotalMessagesSent());
    }

    /**
     * Test printMessages method.
     */
    @Test
    public void testPrintMessages() {
        Message instance = new Message("MSG001", "0821234567", "Hello");
        instance.createMessageHash();
        String result = instance.printMessages();
        assertTrue(result.contains("MSG001"));
        assertTrue(result.contains("0821234567"));
        assertTrue(result.contains("Hello"));
    }

    /**
     * Test returnTotalMessages method.
     */
    @Test
    public void testReturnTotalMessages() {
        Message instance = new Message("MSG001", "0821234567", "Hello");
        instance.sentMessage("1");
        assertEquals(1, instance.returnTotalMessages());
    }

    /**
     * Test getters.
     */
    @Test
    public void testGetters() {
        Message instance = new Message("MSG001", "0821234567", "Hello");
        assertEquals("MSG001", instance.getMessageID());
        assertEquals("0821234567", instance.getRecipient());
        assertEquals("Hello", instance.getMessage());
    }
}
